from flask import Flask, render_template, request, redirect, url_for, session
import random
import unicodedata
import difflib

app = Flask(__name__)
app.secret_key = "gizli-bir-anahtar"  # Replit için gerekli


# Normalize fonksiyonu
def normalize(text):
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('utf-8')
    replacements = {
        "ı": "i",
        "İ": "i",
        "ü": "u",
        "Ü": "u",
        "ö": "o",
        "Ö": "o",
        "ç": "c",
        "Ç": "c",
        "ş": "s",
        "Ş": "s",
        "ğ": "g",
        "Ğ": "g"
    }
    for tr, en in replacements.items():
        text = text.replace(tr, en)
    return text.lower().strip()


# Levenshtein
def levenshtein(s1, s2):
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

yazar_eser = {
    "Şinasi": {
        "eserler": ["Müntehebat-ı Eşar", "Tercüme-i Manzume", "Şair Evlenmesi", "Tercuman-ı Ahval"],
        "alternatif_isimler": ["şinasi"]
    },
    "Namık Kemal": {
        "eserler": ["Hürriyet Gazetesi", "İntibah", "Cezmi", "Vatan Yahut Silistre", "Celaleddin Harzemşah", "Zavallı Çocuk", "Tahrib-i Harabat"],
        "alternatif_isimler": ["namık kemal", "namık", "kemal"]
    },
    "Ziya Paşa": {
        "eserler": ["Eşar Ziya", "Harabat", "Defter-i Amal", "Rüya", "Emile", "Zafername"],
        "alternatif_isimler": ["ziya paşa", "ziya"]
    },
    "Ahmet Mithat Efendi": {
        "eserler": ["Felatun Bey'le Rakım Efendi", "Henüz 17 Yaşında", "Jön Türkler", "Yeniçeriler", "Hasan Mellah", "Hüseyin Fellah", "Esrar-ı Cinayet", "Münşahebat", "Letaifi Rivayat", "Avrupa'da Bir Cevelan", "Eyvah", "Açıkbaş", "Siyavuş", "Çerkes Özdenler", "Menfa"],
        "alternatif_isimler": ["ahmet mithat", "mithat efendi", "mithat"]
    },
    "Şemsettin Sami": {
        "eserler": ["Taaşuk-u Talat ve Fitnat", "Seydi Yahya", "Gave", "Besa yahut Ahde Vefa", "Kamus-u Türki", "Kamus-u Alam"],
        "alternatif_isimler": ["şemsettin sami", "sami"]
    },
    "Ahmet Vefik Paşa": {
        "eserler": ["Kadınlar Mektebi", "Kocalar Mektebi", "Tartüffe", "Don Civani", "Yorgati Dendini", "Hastalık Hastası", "Şecere-i Türk"],
        "alternatif_isimler": ["ahmet vefik", "vefik paşa", "vefik"]
    },
    "Recaizade Mahmut Ekrem": {
        "eserler": ["Nağme-i Seher", "Yarigar-ı Şebab", "Zemzeme I", "Zemzeme II", "Zemzeme III", "Pejmürde", "Muhsin Bey", "Şemsa", "Afife Anjelik", "Çok Bilen Çok Yanılır", "Atala", "Vuslat", "Araba Sevdası", "Takdir-i Eltan", "Talim-i Edebiyat"],
        "alternatif_isimler": ["recaizade", "mahmut ekrem", "recaizade mahmut"]
    },
    "Abdulhak Hamit Tarhan": {
        "eserler": ["Makber", "Sahra", "Validem", "Garam", "Bunlar Odur", "Ölü", "Divaneliklerim Yahut Belde", "Macera-yı Aşk", "Nesteren", "Eşber", "İlhan", "Turhan", "Sardanapal", "Finten", "Liberte"],
        "alternatif_isimler": ["abdülhak hamit", "tarhan", "hamit"]
    },
    "Muallim Naci": {
        "eserler": ["Köylü Kızların Şarkısı", "Ateşpare", "Şerare", "Füruzan", "Sünbüle", "Demdema", "Yazmış Bulundum", "Ömer'in Çocukluğu", "Lügat-ı Naci"],
        "alternatif_isimler": ["muallim naci", "naci"]
    },
    "Samipaşazade Sezai": {
        "eserler": ["Küçük Şeyler", "Sergüzeşt", "Şir", "İclal"],
        "alternatif_isimler": ["samipaşazade sezai", "sezai"]
    },
    "Nabizade Nazım": {
        "eserler": ["Karabibik", "Zehra", "Yadigarlarım", "Zavallı Kız", "Haşpa", "Sevda", "Heves Ettim"],
        "alternatif_isimler": ["nabizade nazım", "nazım"]
    },
    "Tevfik Fikret": {
        "eserler": ["Sis", "Rübab-ı Şikeste", "Tarih-i Kadim", "Bir Lahza-i Taahhür", "Haluk'un Defteri", "Şermin", "Doksan Beşe Doğru", "Han-ı Yağma", "Süha ve Pervin", "Ferda"],
        "alternatif_isimler": ["tevfik", "fikfik", "fikret"]
    },
    "Cenap Şahabettin": {
        "eserler": ["Elhan-ı Şita", "Tamat", "Körebe", "Yalan", "Tiryaki Sözleri", "Avrupa Mektupları", "Suriye Mektupları", "Haf Yolunda", "Evrak-ı Eyyam", "Nesl-i Harp", "Afak-ı Irak"],
        "alternatif_isimler": ["cenap", "şahabettin", "cenap şahabettin"]
    },
    "Halit Ziya Uşaklıgil": {
        "eserler": ["Mai ve Siyah", "Nesl-i Ahir", "Kırık Hayatlar", "Bir Ölünün Defteri", "Ferdi ve Şurekası", "Bir Yazın Tarihi", "Solgun Demet", "İzmir Hikayeleri", "Bir Acı Hikaye", "Kadın Pençesi", "Mezardan Sesler", "Kırk Yıl", "Saray ve Ötesi", "Kabus", "Firuzan", "Fare"],
        "alternatif_isimler": ["halit ziya", "uşaklıgil", "halit"]
    },
    "Mehmet Rauf": {
        "eserler": ["Eylül", "Genç Kız Kalbi", "Halas", "Ferda-yı Garam", "Bir Zambağım Hikayesi", "Karanfil ve Yasemen", "Son Emel", "Aşıkane", "Pençe", "Cidal", "Ferdi ve Şurekası", "Siyah İnciler"],
        "alternatif_isimler": ["mehmet rauf", "rauf"]
    },
    "Hüseyin Suat Yalçın": {
        "eserler": ["Nadide", "Hayal İçinde", "Hayat-ı Muhayyat", "Niçin Aldatırlarmış", "Kavgalarım", "Edebi Hatıralar", "Edebiyat ve Hukuk"],
        "alternatif_isimler": ["hüseyin suat", "yalçın"]
    },
    "Süleyman Nazif": {
        "eserler": ["Gizli Figanlar", "Malta Geceleri", "Fırak-ı Irak"],
        "alternatif_isimler": ["süleyman nazif", "nazif"]
    },
    "Hüseyin Rahmi Gürpınar": {
        "eserler": ["Şıpsevdi", "Şık", "Kuyruklu Yıldız Altında İzdivaç", "Mürebbiye", "İffet", "Namus", "Utanmaz Adam", "Gönül Bir Yel Değirmenidir", "Katil Buse", "Melek Sanmıştım Şeytanı", "Kadınlar Vaizi", "Tokuşan Kafalar", "Kadın Erkekleşince", "Gülbahar Hanım"],
        "alternatif_isimler": ["hüseyin rahmi", "gürpınar", "rahmi"]
    },
    "Ahmet Rasim": {
        "eserler": ["Şehir Mektupları", "Eşkal-ı Zaman", "Muharrir Bu Ya", "Cidd ü Mizah", "Falak", "Gecelerim", "Meyl-i Dil", "Güzel Eleni"],
        "alternatif_isimler": ["ahmet rasim", "rasim"]
    },
    "Ahmet Haşim": {
        "eserler": ["Piyale", "Göl Saatleri", "Bize Göre", "Gülbahar-ı Laklakan"],
        "alternatif_isimler": ["ahmet haşim", "haşim"]
    },
    "Emin Bülent Serdaroğlu": {
        "eserler": ["Kin", " "],
        "alternatif_isimler": ["emin bülent", "serdaroğlu"]
    },
    "Ömer Seyfettin": {
        "eserler": ["İlk Namaz", "And", "Kaşağı", "Bahar ve Kelebekler", "Forsa", "Yüksek Ökçeler", "Perili Köşk", "Pembe İncili Kaftan", "Diyet", "Primo Türk Çocuğu", "Efruz Bey"],
        "alternatif_isimler": ["ömer seyfettin", "seyfettin"]
    },
    "Ziya Gökalp": {
        "eserler": ["Kızıl Elma", "Altın Işık", "Yeni Hayat"],
        "alternatif_isimler": ["ziya gökalp", "gökalp", "ziya"]
    },
    "Ali Canip Yöntem": {
        "eserler": ["Geçtiğim Yol", "Milli Edebiyat Meseleleri ve Cenap Bey'le Münakaşalarım"],
        "alternatif_isimler": ["ali canip", "yöntem", "ali canip yöntem"]
    },
    "Mehmet Emin Yurdakul": {
        "eserler": ["Cenge Giderken", "Turan'a Doğru", "Ordunun Destanı", "Zafer Yolunda", "Ey Türk Uyan"],
        "alternatif_isimler": ["mehmet emin", "yurdakul", "mehmet emin yurdakul"]
    },
    "Refik Halit Karay": {
        "eserler": ["Memleket Hikayeleri", "Gurbet Hikayeleri", "Bugünün Saraylısı", "İstanbul'un İç Yüzü", "Çete", "Nilgün", "Sürgün", "Yezid'in Kızı"],
        "alternatif_isimler": ["refik halit", "karay", "refik"]
    },
    "Halide Edib Adıvar": {
        "eserler": ["Ateşten Gömlek", "Vurun Kahpeye", "Sinekli Bakkal", "Tatarcık", "Yeni Turan", "Seviye Talip", "Kalp Ağrısı", "Zeyno'nun Oğlu", "Yolpalas Cinayeti", "Dağa Çıkan Kurt", "Harap Mabetler", "Kenan Çobanları", "Maske ve Ruh", "Mor Salkımlı Ev", "Türk'ün Ateşle İmtihanı"],
        "alternatif_isimler": ["halide edib", "adıvar", "halide"]
    },
    "Reşat Nuri Güntekin": {
        "eserler": ["Harabelerin Çiçeği", "Yaprak Dökümü", "Dudaktan Kalbe", "Çalıkuşu", "Kan Davası", "Acımak", "Yeşil Gece", "Miskinler Tekkesi", "Gizli El", "Damga", "Leyla ile Mecnun", "Boyunduruk", "Sönmüş Yıldızlar", "Hançer", "Tanrı Dağı Ziyareti", "Anadolu Notları"],
        "alternatif_isimler": ["reşat nuri", "güntekin", "reşat"]
    },
    "Yakup Kadri Karaosmanoğlu": {
        "eserler": ["Yaban", "Kiralık Konak", "Hüküm Gecesi", "Ankara", "Sodom ve Gomore", "Hep O Şarkı", "Nur Baba", "Rahmet", "Bir Serencam", "Sağanak", "Nirvana", "Erenlerin Bağından", "Okun Ucundan", "Zoraki Diplomat"],
        "alternatif_isimler": ["yakup kadri", "karaosmanoğlu", "yakup"]
    },
    "Ahmet Hikmet Müftüoğlu": {
        "eserler": ["Haristan ve Gülistan", "Çağlayanlar", "Gönül Hanım"],
        "alternatif_isimler": ["ahmet hikmet", "müftüoğlu", "ahmet müftüoğlu"]
    },
    "Yahya Kemal Beyatlı": {
        "eserler": ["Kendi Gök Kubbemiz", "Eski Şiirin Rüzgarıyla", "Rubailer", "Eğil Dağlar", "Aziz İstanbul"],
        "alternatif_isimler": ["yahya kemal", "beyatlı", "yahya"]
    },
    "Mehmet Akif Ersoy": {
        "eserler": ["Safahat", "Kufe", "Seyfi Baba", "Mahalle Kahvesi", "Meyhane"],
        "alternatif_isimler": ["mehmet akif", "ersoy", "akif"]
    },
    "Faruk Nafiz Çamlıbel": {
        "eserler": ["Han Duvarları", "Çoban Çeşmesi", "Dinle Neyden", "Suda Halkalar", "Akıncı", "Türkler", "Zindan Duvarları", "Özyurt", "Canavar", "Yayla Kartalı", "Yıldız Yağmuru"],
        "alternatif_isimler": ["faruk nafiz", "çamlıbel"]
    },
    "Yusuf Ziya Ortaç": {
        "eserler": ["Kuş Cıvıltıları", "Akından Akına", "Cenk Ufukları", "Kürkçü Dükkanı", "Göç", "Üç Katlı Ev", "Nikahta Keramet", "Kördüğüm"],
        "alternatif_isimler": ["yusuf ziya", "ortaç"]
    },
    "Orhan Seyfi Orhon": {
        "eserler": ["Fırtına ve Kar", "Peri Kızıyla Çoban Hikayesi", "Gönülden Sesler", "Veda Busesi"],
        "alternatif_isimler": ["orhan seyfi", "orhon"]
    },
    "Halit Fahri Ozansoy": {
        "eserler": ["Aruza Veda", "Efsaneler", "Sulara Dolan Gözler", "Cenk Duyguları"],
        "alternatif_isimler": ["halit fahri", "ozansoy"]
    },
    "Enis Behiç Koryürek": {
        "eserler": ["Eski Korsan Hikayeleri", "Gemiciler", "Miras", "Güneşin Ölümü", "Varidat-ı Süleyman"],
        "alternatif_isimler": ["enis behiç", "koryürek"]
    },
    "Ahmet Hamdi Tanpınar": {
        "eserler": ["Huzur", "Mahur Beste", "Sahnenin Dışındakiler", "Saatleri Ayarlama Enstitüsü"],
        "alternatif_isimler": ["ahmet hamdi", "tanpınar"]
    },
    "Necip Fazıl Kısakürek": {
        "eserler": ["Kaldırımlar", "Çile", "Kafa Kağıdı"],
        "alternatif_isimler": ["necip fazıl", "kısakürek", "necip"]
    },
    "Cahit Sıtkı Tarancı": {
        "eserler": ["Ömrümde Sükut", "Otuz Beş Yaş", "Düşen Güzel", "Sonrası", "Ziyaya Mektuplar", "Gün Eksilmesin Penceremden"],
        "alternatif_isimler": ["cahit sıtkı", "tarancı", "cahit"]
    },
    "Ahmet Muhip Dıranas": {
        "eserler": ["Fahriye Abla", "Kar", "Serenad"],
        "alternatif_isimler": ["ahmet muhip", "dıranas"]
    },
    "Ahmet Halet Çelebi": {
        "eserler": ["He", "Lamelif", "Om Mani Padme Hum"],
        "alternatif_isimler": ["ahmet halet", "çelebi"]
    },
    "Özdemir Asaf": {
        "eserler": ["Lavinia", "Çiçek Senfonisi"],
        "alternatif_isimler": ["özdemir asaf", "özdemir"]
    },
    "Fazıl Hüsnü Dağlarca": {
        "eserler": ["Çocuk ve Allah", "Havaya Çizilen Bulut", "Üç Şehitler Destanı", "Çakırın Destanı"],
        "alternatif_isimler": ["fazıl hüsnü dağlarca", "fazıl dağlarca", "dağlarca"]
    },
    "Ziya Osman Saba": {
        "eserler": ["Sebil ve Güvercinler", "Mesut İnsanlar Fotoğrafnamesi"],
        "alternatif_isimler": ["ziya osman saba", "ziya saba", "osman saba"]
    },
    "Cevdet Kudret Solok": {
        "eserler": ["Birinci Perde", "Süleymanın Dünyası"],
        "alternatif_isimler": ["cevdet kudret solok", "cevdet kudret", "kudret solok"]
    },
    "Yaşar Nabi Nayır": {
        "eserler": ["Kahramanlar", "Onar Mısra", "Varlık dergisi"],
        "alternatif_isimler": ["yaşar nabi nayır", "yaşar nayır", "nabi nayır"]
    },
    "Kenan Hulusi Koray": {
        "eserler": ["Bahar Hikayeleri", "Bir Otelde Yedi Kişi"],
        "alternatif_isimler": ["kenan hulusi koray", "kenan koray", "hulusi koray"]
    },
    "Sabri Esat Siyavuşgil": {
        "eserler": ["Odalar ve Sofalar", "x"],
        "alternatif_isimler": ["sabri esat siyavuşgil", "sabri esat", "esat siyavuşgil"]
    },
    "Nazım Hikmet Ran": {
        "eserler": [
            "Benerce Kendini Niçin Öldürdü", "835 Satır", "Simauna Kadısı Oğlu Şeyh Bedrettin Destanı",
            "Memleketimden İnsan Manzaraları", "Kurtuluş Savaşı Destanı", "Kuvayi Milliye Destanı", 
            "Jakond ile Si-ya-u", "Kafatası", "Yusuf ile Manofis", "Yaşamak Güzel Şey Be Kardeşim", 
            "Kan Konuşmaz", "Kemal Tahire Mapushaneden Mektuplar"
        ],
        "alternatif_isimler": ["nazım hikmet ran", "nazım hikmet", "hikmet ran", "nazım"]
    },
    "Rıfat Ilgaz": {
        "eserler": ["Üsküdarda Sabah Oldu", "Karartma Geceleri", "Hababam Sınıfı"],
        "alternatif_isimler": ["rıfat ilgaz", "rıfat", "ilgaz"]
    },
    "Arif Nihat Asya (Bayrak Şairi)": {
        "eserler": ["Bir Bayrak Rüzgar Bekliyor", "Yastığımın Rüyası", "Rübaiyyatı Arif"],
        "alternatif_isimler": ["arif nihat asya", "bayrak şairi", "asya"]
    },
    "Kemalettin Kamu (Gurbet şairi)": {
        "eserler": ["Gurbet", "Bingöl Çobanları"],
        "alternatif_isimler": ["kemalettin kamu", "gurbet şairi", "kamu"]
    },
    "Ahmet Kutsi Tecer": {
        "eserler": ["Neredesin", "Orada Bir Köy Var Uzakta", "Halay Çeken Kızlar", "Koçyiğit Köroğlu"],
        "alternatif_isimler": ["ahmet kutsi tecer", "kutsi tecer", "ahmet tecer"]
    },
    "Orhan Şaik Gökyay": {
        "eserler": ["Destursuz Bağa Girenler", "Bu Vatan Kimin", "Birkaç Şiir"],
        "alternatif_isimler": ["orhan şaik gökyay", "şaik gökyay", "orhan gökyay"]
    },
    "Ömer Bedrettin Uşaklı": {
        "eserler": ["Deniz Sarhoşları", "Sarıkız Mermerleri"],
        "alternatif_isimler": ["ömer bedrettin uşaklı", "bedrettin uşaklı", "ömer uşaklı"]
    },
    "Behçet Kemal Çağlar": {
        "eserler": ["Erciyesten Kopan Çığ", "Ankaralı Aşık Ömerin Cumhuriyet Destanı", "Çoban", "Atilla"],
        "alternatif_isimler": ["behçet kemal çağlar", "behçet çağlar", "kemal çağlar"]
    },
    "Zeki Ömer Defne": {
        "eserler": ["Kardelenler", "Sessiz Nehir"],
        "alternatif_isimler": ["zeki ömer defne", "zeki defne", "ömer defne"]
    },
    "Halide Nusret Zorlutuna": {
        "eserler": ["Geceden Taşan Dertler", "Yayla Türküsü", "Git Bahar"],
        "alternatif_isimler": ["halide nusret zorlutuna", "halide zorlutuna", "nusret zorlutuna"]
    },
    "Şükufe Nihal Başar": {
        "eserler": ["Hazan Rüzgarları", "Gayya"],
        "alternatif_isimler": ["şükufe nihal başar", "şükufe başar", "nihal başar"]
    },
    "Ceyhun Atıf Kansu": {
        "eserler": ["Bir Çocuk Bahçesinde", "Bağbozumu Sofrası"],
        "alternatif_isimler": ["ceyhün atıf kansu", "ceyhün kansu", "atıf kansu"]
    },
    "Orhan Veli Kanık": {
        "eserler": ["Garip", "Vazgeçemediğim", "Karşı", "Nasrettin Hoca Fıkraları"],
        "alternatif_isimler": ["orhan veli kanık", "orhan veli", "kanık"]
    },
    "Melih Cevdet Anday": {
        "eserler": ["Rahatı Kaçan Ağaç", "Telgrafhane", "Kolları Bağlı Odysseus", "Mikadonun Çöpleri"],
        "alternatif_isimler": ["melih cevdet anday", "cevdet anday", "melih anday"]
    },
    "Oktay Rıfat Horozcu": {
        "eserler": ["Danaburnu", "Çil Horoz"],
        "alternatif_isimler": ["oktay rıfat horozcu", "rıfat horozcu", "oktay horozcu"]
    },
    "Necati Cumalı": {
        "eserler": ["Tütün Zamanı", "Acı Tütün", "Zeliş", "Susuz Yaz"],
        "alternatif_isimler": ["necati cumalı", "cumalı"]
    },
    "Cahit Külebi": {
        "eserler": ["Atatürk Kurtuluş Savaşında", "Adamın Biri"],
        "alternatif_isimler": ["cahit külebi", "külebi"]
    },
    "Sabahattin Kudret Aksal": {
        "eserler": ["Sarıklı Kahve", "Gün Işığı", "Gazoz Ağacı", "Yaralı Hayvan"],
        "alternatif_isimler": ["sabahattin kudret aksal", "kudret aksal", "aksal"]
    },
    "Cahit Zarifoğlu": {
        "eserler": ["Yedi Güzel Adam", "İns", "Katıraslan"],
        "alternatif_isimler": ["cahit zarifoğlu", "zarifoğlu"]
    },
    "Hilmi Yavuz": {
        "eserler": ["Bakış Kuşu", "Bedrettin Üzerine Şiirler"],
        "alternatif_isimler": ["hilmi yavuz", "yavuz"]
    },
    "Erdem Beyazıt": {
        "eserler": ["Şebep Ey", "Risaleler", "İpek Youndan Afganistana"],
        "alternatif_isimler": ["erdem beyazıt", "beyazıt"]
    },
    "Bedri Rahmi Eyüpoğlu": {
        "eserler": ["Karadut", "Yaradana Mektuplar", "Dol Karabakır Dol", "Tezek"],
        "alternatif_isimler": ["bedri rahmi eyüpoğlu", "rahmi eyüpoğlu", "eyüpoğlu"]
    },
    "Attila İlhan": {
        "eserler": ["Duvar", "Sisler Bulvarı", "Yağmur Kaçağı", "Yasak Sevişmek", "Elde Var Hüzün", "Sokaktaki Adam", "Kurtlar Sofrası", "Yaraya Tuz Basmak", "Zenciler Birbirine Benzemez", "Fena Halde Lemn", "Hangi Serisi"],
        "alternatif_isimler": ["attila ilhan", "ilhan"]
    },
    "Ferit Edgü": {
        "eserler": ["O", "Hakkaride Bir Mevsim", "Bozgun", "Av"],
        "alternatif_isimler": ["ferit edgü", "edgü"]
    },
    "İlhan Berk": {
        "eserler": ["Güneşi Yakanların Selamı", "Mısır Kalyoniğne", "Galile Denizi"],
        "alternatif_isimler": ["ilhan berk", "berk"]
    },
    "Cemal Süreya": {
        "eserler": ["Üvercinka", "Beni Öp Sonra Doğur Beni", "Güz Bitiği"],
        "alternatif_isimler": ["cemal süreya", "süreya"]
    },
    "Ülkü Tamer": {
        "eserler": ["Ezra ile Gary", "İçime Çektiğim Hava Değil Gökyüzüdür", "Allaben Öyküleri"],
        "alternatif_isimler": ["ülkü tamer", "tamer"]
    },
    "Edip Cansever": {
        "eserler": ["Yerçekimli Karanfil", "İkindi Üstü", "Dirlik-Düzenlik", "Nerde Antigone"],
        "alternatif_isimler": ["edip cansever", "cansever"]
    },
    "Sezai Karakoç": {
        "eserler": ["Monna Rosa", "Şahdamar", "Körfez", "Hızırla Kırk Saat", "Tahanın Kitabı", "Gül Muştunu"],
        "alternatif_isimler": ["sezai karakoç", "karakoç"]
    },
    "Turgut Uyar": {
        "eserler": ["Arzı Hal", "Türkiyem", "Dünyanın En Güzel Arabistanı", "Tütünler Islak", "Büyük Saat", "Dün Yok mu?", "Divan", "Kayayı Delen Zincir"],
        "alternatif_isimler": ["turgut uyar", "uyar"]
    },
    "Ece Ayhan": {
        "eserler": ["Bakışsız Bir Kedi Kara", "Yort Savul"],
        "alternatif_isimler": ["ece ayhan", "ayhan"]
    },
    "Ataol Behramoğlu": {
        "eserler": ["Bir Ermeni General", "Bir Gün Mutlaka", "Yaşadıklarımdan Öğrendiğim Bir Şey Var"],
        "alternatif_isimler": ["ataol behramoğlu", "behramoğlu"]
    },
    "İsmet Özel": {
        "eserler": ["Evet İsyan", "Erbain", "Celladıma Gülümserken"],
        "alternatif_isimler": ["ismet özel", "özel"]
    },
    "Süreyya Berfe": {
        "eserler": ["Kasaba", "Nabiga"],
        "alternatif_isimler": ["süreyya berfe", "berfe"]
    },
    "Refik Durbaş": {
        "eserler": ["Kuş Tufanı", "Hücremde Ayışığı", "Çırak Aranıyor"],
        "alternatif_isimler": ["refik durbaş", "durbaş"]
    },
    "Memduh Şevket Esendal": {
        "eserler": ["Ayaşlı ve Kiracıları", "Otlakçı"],
        "alternatif_isimler": ["memduh şevket esendal", "esendal"]
    },
    "Mithat Cemal Kuntay": {
        "eserler": ["Üç İstanbul", "x "],
        "alternatif_isimler": ["mithat cemal kuntay", "kuntay"]
    },
    "Aka Gündüz": {
        "eserler": ["Dikmen Yıldızı", " x"],
        "alternatif_isimler": ["aka gündüz", "gündüz"]
    },
    "Sabahattin Ali": {
        "eserler": ["Kuyucaklı Yusuf", "İçimizdeki Şeytan", "Kürk Mantolu Madonna"],
        "alternatif_isimler": ["sabahattin ali", "ali"]
    },
    "Orhan Kemal": {
        "eserler": ["Çukurova Yöresi", "Argo Dil", "Realist", "Baba Evi", "Avare Yıllar", "Bereketli Topraklar Üzerinde", "Ekici ve Oğulları"],
        "alternatif_isimler": ["orhan kemal", "kemal"]
    },
    "Yaşar Kemal": {
        "eserler": ["Çukurova Yöresi", "Efsaneleştirmeli anlatım", "İnce Memed", "Teneke", "Orta Direk", "Yer Demir Gök Bakır", "Ölmez Otu", "Demirciler Çarşısı Cinayeti", "Yusufçu Yusuf", "Yılanı Öldürseler"],
        "alternatif_isimler": ["yaşar kemal", "kemal"]
    },
    "Kemal Tahir": {
        "eserler": ["Çankırı Çorum Yöresi", "Hapishane ve Mahkumlar", "Tezli Roman", "Devlet Ana", "Esir Şehrin İnsanları", "Esir Şehrin Mahpusu", "Hür Şehrin İnsanları", "Yol Ayrımı", "Kurt Kanunu"],
        "alternatif_isimler": ["kemal tahir", "tahir"]
    },
    "Talip Apaydın": {
        "eserler": ["Sarı Traktör", "Vatan Dediler"],
        "alternatif_isimler": ["talip apaydın", "apaydin"]
    },
    "Fakir Baykurt": {
        "eserler": ["Yılanları Öcü", "Irazcanın Dirliği", "Kara Ahmet Destanı"],
        "alternatif_isimler": ["fakir baykurt", "baykurt"]
    },
    "Sadri Ertem": {
        "eserler": ["Çıkrıklar Durunca", "Bacayı İndir Bacayı Kaldır"],
        "alternatif_isimler": ["sadri ertem", "ertem"]
    },
    "Kemal Bilbaşar": {
        "eserler": ["Doğu Anadolu Yöresi", "Cemo", "Memo"],
        "alternatif_isimler": ["kemal bilbaşar", "bilbaşar"]
    },
    "Faik Baysal": {
        "eserler": ["Drina'da Son Gün", "Sarduvan"],
        "alternatif_isimler": ["faik baysal", "baysal"]
    },
    "Samim Kocagöz": {
        "eserler": ["Kalpaklılar", "Doludizgin"],
        "alternatif_isimler": ["samim kocagöz", "kocagöz"]
    },
    "Cevat Şakir Kabaağaçlı (Halikarnas Balıkçısı)": {
        "eserler": ["Aganta Burina Burinata", "Uluç Reis"],
        "alternatif_isimler": ["cevat şakir kabaağaçlı", "halikarnas balıkçısı", "kabaağaçlı", "balıkçı"]
    },
    "Peyami Safa": {
        "eserler": ["Dokuzuncu Hariciye Koğuşu", "Fatih Harbiye", "Yalnızız", "Matmazel Noralyanın Koltuğu", "Sözde Kızlar"],
        "alternatif_isimler": ["peyami safa", "safa"]
    },
    "Adulhak Şinasi Hisar": {
        "eserler": ["Fehim Bey ve Biz", "Çamlıcadaki Eniştemiz", "Ali Nizami Beyin Alafranglığı ve Şeyhliği"],
        "alternatif_isimler": ["adulhak şinasi hisar", "hisar"]
    },
    "Tarık Buğra": {
        "eserler": ["Küçük Ağa", "İbişin Rüyası", "Küçük Ağa Ankarada", "Firavun İmamı", "Osmancık"],
        "alternatif_isimler": ["tarık buğra", "buğra"]
    },
    "Mustafa Kutlu": {
        "eserler": ["Yoksulluk İçimizde", "Ya Tahammül Ya Sefer"],
        "alternatif_isimler": ["mustafa kutlu", "kutlu"]
    },
    "Selim İleri": {
        "eserler": ["Her Gece Bodrum", "Yarın Yapayalnız", "Destan Gönüller", "Cumartesi Yalnızlığı", "Pastırma Yazı"],
        "alternatif_isimler": ["selim ileri", "ileri"]
    },
    "Sait Faik Abasıyanık": {
        "eserler": ["Semaver", "Sarnıç", "Lüzumsuz Adam", "Alemdağda Var Bir Yılan", "Medarı Maişet Motoru"],
        "alternatif_isimler": ["sait faik abasıyanık", "faik abasıyanık", "sait faik"]
    },
    "Oğuz Atay": {
        "eserler": ["Tutunamayanlar", "Tehlikeli Oyunlar", "Bir Bilim Adamının Romanı", "Korkuyu Beklerken"],
        "alternatif_isimler": ["oğuz atay", "atay"]
    },
    "Haldun Taner": {
        "eserler": ["Yaşasın Demokrasi", "Tuş", "Şişhaneye Yağmur Yağıyordu", "On İkiye Bir Var", "Keşanlı Ali Destanı", "Gözlerimi Kaparım Vazifemi Yaparım", "Fazilet Eczanesi"],
        "alternatif_isimler": ["haldun taner", "taner"]
    },
    "Yusuf Atılgan": {
        "eserler": ["Aylak Adam", "Anayurt Oteli"],
        "alternatif_isimler": ["yusuf atılgan", "atılgan"]
    },
    "Orhan Pamuk": {
        "eserler": ["Kar", "Kara Kitap", "Yeni Hayat"],
        "alternatif_isimler": ["orhan pamuk", "pamuk", "orhan yamuk"]
    },
    "Rasim Özdenören": {
        "eserler": ["Gül Yetiştiren Adam","  x"],
        "alternatif_isimler": ["rasim özdenören", "özdenören"]
    },
    "Bilge Karasu": {
        "eserler": ["Troyada Ölüm Vardı", " x  "],
        "alternatif_isimler": ["bilge karasu", "karasu"]
    },
    "Adalet Ağaoğlu": {
        "eserler": ["Ölmeye Yatmak", "Bir Düğün Gecesi", "Hayır", "Fikrimin İnce Gülü", "Yüksek Gerilim", "Sessizliğin İlk Sesi"],
        "alternatif_isimler": ["adalet ağaoğlu", "ağaoğlu"]
    },
    "Füruzan": {
        "eserler": ["Parasız Yatılı", "Kuşatma", "Benim Sinemalarım", "47liler"],
        "alternatif_isimler": ["füruzan"]
    },
    "Nezihe Meriç": {
        "eserler": ["Korsan Çıkmazı", "Bozbulanık", "Topal Koşma"],
        "alternatif_isimler": ["nezihe meriç", "meriç"]
    },
    "Oktay Akbal": {
        "eserler": ["Önce Ekmekler Bozuldu", "Suçumuz İnsan Olmak"],
        "alternatif_isimler": ["oktay akbal", "akbal"]
    },
    "İnci Aral": {
        "eserler": ["Kırın Resimleri", "Ağda Zamanı", "Ölü Erkek Kuşlar"],
        "alternatif_isimler": ["inci aral", "aral"]
    },
    "Vüsat Orhan Bener": {
        "eserler": ["Dost", "Yaşamasız"],
        "alternatif_isimler": ["vüsat orhan bener", "bener"]
    },
    "Sevinç Çokum": {
        "eserler": ["Zor", "Hilal Görününce"],
        "alternatif_isimler": ["sevinç çokum", "çokum"]
    },
    "Latife Tekin": {
        "eserler": ["Sevgili Arsız Ölüm", "Berci Kristin Çöp Masalları"],
        "alternatif_isimler": ["latife tekin", "tekin"]
    }
}

works = {
    "Araba Sevdası": "Bihruz Bey, Periveş, Keşfi Bey",
    "İntibah": "Ali Bey, Dilaşup, Mahpeyker",
    "Sergüzeşt": "Dilber, Asaf Pasa",
    "Mai ve Siyah": "Ahmet Cemil, Lamia, Hüseyin Nazmi",
    "Kırık Hayatlar": "Ömer Behiç, Vedide, Leyla",
    "Eylül": "Suat, Necip, Süreyya",
    "Şıpsevdi": "Meftun Bey, Kasım Efendi, Mahir",
    "Ateşten Gömlek": "Peyami, Ayşe, Binbaşı İhsan",
    "Vurun Kahpeye": "Aliye, Tosun Bey",
    "Sinekli Bakkal": "Rabia, Peregrini, Vehbi Efendi",
    "Yaban": "Ahmet Celal, Emine, Salih Ağa",
    "Ankara": "Selma Hanım, Binbaşı Hakkı, Nazif Bey",
    "Kiralık Konak": "Naim Efendi, Sakine, Seniha, Servet Bey",
    "Yaprak Dökümü": "Ali Riza Bey, Fikret, Necla",
    "Esir Şehir Üçlemesi": "Kamil Bey, Neriman Hanim, Ayşe",
    "Bereketli Topraklar Üzerinde": "İflahsızın Yusuf, Köse Hasan, Pehlivan Ali",
    "Yılanların Öcü": "Irazca, Kara Bayram",
    "Sarı Traktör": "Arif",
    "Susuz Yaz": "Hasan, Osman, Bahar",
    "Ayaşlı ile Kiracıları": "İbrahim Efendi, Hasan Bey, Rasim",
    "Fatih Harbiye": "Neriman, Şinasi, Macit",
    "Aganta Burina Burinata": "Mahmut, Süleyman Kaptan",
    "Huzur": "Mümtaz, Nuran, Suat, İhsan",
    "Mahur Beste": "Behçet Efendi, İsmail Molla",
    "Saatleri Ayarlama Enstitüsü": "Hayri İrdal, Halit Ayarci",
    "Küçük Ağa": "Çolak Salih, İstanbullu İmam",
    "Tutunamayanlar": "Selim Işık, Turgut Özben",
    "Kara Kitap": "Galip, Rüya, Celal Salık",
    "Yeni Hayat": "Osman, Canan, Mehmet",
    "Kar": "Ka, Turgut Bey",
    "Aylak Adam": "C., Ayse",
    "Anayurt Oteli": "Zebercet",
    "Ölmeye Yatmak": "Aysel, Salih Efendi, Dündar Öğretmen",
    "Fikrimin İnce Gülü": "Bayram, Kezban",
    "Cezmi": "Cezmi",
    "Zehra": "Zehra",
    "Nesl-i Ahir": "Süleyman, Nüzhet",
    "Şık": "Şahzade, Şöhret, Madam Potiş",
    "Karartma Geceleri": "Mustafa Ural",
    "Tütün Üçlemesi": "Zeliha, Recep, Rabia",
    "Her Gece Bodrum": "Cem, Murat, Tarık",
    "Sevgili Arsız Ölüm": "Huvat, Atiye, Nuğber"

}


def similarity(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/yazar", methods=["GET", "POST"])
def yazar():
        if "puan" not in session or "soru" not in session or "yazar" not in session or "eserler" not in session:
            session["puan"] = 0
            session["soru"] = 1
            session["kullanilan"] = []
            available = [y for y in yazar_eser if y not in session["kullanilan"]]
            session["yazar"] = random.choice(available)
            session["kullanilan"].append(session["yazar"])
            session["eserler"] = random.sample(yazar_eser[session["yazar"]]["eserler"], 2)

        if request.method == "POST":
            cevap = normalize(request.form["cevap"])
            dogru = False
            for alt in yazar_eser[session["yazar"]]["alternatif_isimler"]:
                if levenshtein(cevap, normalize(alt)) <= 3:
                    dogru = True
                    break
                if levenshtein(cevap, alt) <= 3:
                    dogru = True
                    break

            if dogru:
                session["puan"] += 10
                sonuc = "✅ Doğru!"
            else:
                sonuc = f"❌ Yanlış cevap. Doğru yazar: {session['yazar']}"

            session["soru"] += 1
            if session["soru"] > 10:
                puan = session["puan"]
                session.clear()
                return render_template("yazar.html", bitti=True, puan=puan)
            else:
                available = [y for y in yazar_eser if y not in session["kullanilan"]]
                session["yazar"] = random.choice(available)
                session["kullanilan"].append(session["yazar"])
                session["eserler"] = random.sample(yazar_eser[session["yazar"]]["eserler"], 2)

                return render_template("yazar.html",
                                       eserler=session["eserler"],
                                       soru=session["soru"],
                                       sonuc=sonuc)

        # GET isteğinde doğrudan mevcut session verileriyle sayfa gösterilir
        return render_template("yazar.html",
                               eserler=session["eserler"],
                               soru=session["soru"])



@app.route("/eser", methods=["GET", "POST"])
def eser():
    if "eser_soru" not in session:
        session["eser_soru"] = 1
        session["dogru"] = 0
        session["sorular"] = random.sample(list(works.items()), 10)

    eser, karakterler = session["sorular"][session["eser_soru"] - 1]

    if request.method == "POST":
        cevap = normalize(request.form["cevap"])
        if cevap == "bilmiyorum":
            sonuc = f"🚫 Yanıt yok. Doğru: {eser}"
        elif cevap == normalize(eser) or similarity(cevap,
                                                    normalize(eser)) >= 0.9:
            session["dogru"] += 1
            sonuc = "✅ Doğru!"
        else:
            sonuc = f"❌ Yanlış cevap. Doğru eser: {eser}"

        session["eser_soru"] += 1
        if session["eser_soru"] > 10:
            puan = session["dogru"]
            session.clear()
            return render_template("eser.html", bitti=True, puan=puan)
        else:
            yeni_eser, yeni_karakterler = session["sorular"][
                session["eser_soru"] - 1]
            return render_template("eser.html",
                                   karakterler=yeni_karakterler,
                                   soru=session["eser_soru"],
                                   sonuc=sonuc)

    return render_template("eser.html",
                           karakterler=karakterler,
                           soru=session["eser_soru"])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)